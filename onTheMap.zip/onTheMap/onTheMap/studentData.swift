//
//  studentData.swift
//  onTheMap
//
//  Created by albandry on 27/05/2019.
//  Copyright © 2019 albandry. All rights reserved.
//

import Foundation

class studentData {
    
    static var objectId = ""
    static var uniqueKey = ""
    static var firstName = ""
    static var lastName = ""
    static var mapString = ""
    static var mediaURL = ""
    static var latitude : Double = 0.0
    static var longtitude : Double = 0.0
    static var createdAt = ""
    static var updateAt = ""
    static var ACL = ""
    
    static var data : [studentLocation] = []
}
