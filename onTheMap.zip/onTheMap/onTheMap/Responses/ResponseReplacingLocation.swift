//
//  ResponseReplacingLocation.swift
//  onTheMap
//
//  Created by albandry on 31/05/2019.
//  Copyright © 2019 albandry. All rights reserved.
//

import Foundation

struct ResponseReplacingLocation: Codable {
    
    let updatedAt: String
    
}
