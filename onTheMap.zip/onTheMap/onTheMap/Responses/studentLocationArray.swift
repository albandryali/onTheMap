//
//  studentLocations.swift
//  onTheMap
//
//  Created by albandry on 27/05/2019.
//  Copyright © 2019 albandry. All rights reserved.
//

import Foundation

struct studentLocationArray : Codable {
    
   let studentlocation : [studentLocation]
    

}
