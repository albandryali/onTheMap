//
//  newLocationRespnse.swift
//  onTheMap
//
//  Created by albandry on 29/05/2019.
//  Copyright © 2019 albandry. All rights reserved.
//

import Foundation

struct newLocationRespnse: Codable {
    
    let createdAt: String
    let objectId: String
    
}
