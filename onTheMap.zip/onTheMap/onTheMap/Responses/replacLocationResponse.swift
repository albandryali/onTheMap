//
//  replacLocationResponse.swift
//  onTheMap
//
//  Created by albandry on 28/05/2019.
//  Copyright © 2019 albandry. All rights reserved.
//

import Foundation

struct replacLocationResponse : Codable {
    let updateAt : String
}
